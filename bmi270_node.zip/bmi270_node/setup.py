from setuptools import setup

package_name = 'bmi270_node'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name, f'{package_name}.bmi270'],
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools', 'rclpy', 'smbus2'],
    zip_safe=True,
    maintainer='yourname',
    maintainer_email='your@email.com',
    description='BMI270 ROS2 Python Node with local driver',
    license='MIT',
    entry_points={
        'console_scripts': [
            'bmi_node = bmi270_node.bmi_node:main',
        ],
    },
)
