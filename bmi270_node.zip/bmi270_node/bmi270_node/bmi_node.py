from rclpy.node import Node
import rclpy
from bmi270_node.bmi270.BMI270 import BMI270
from sensor_msgs.msg import Imu
from rclpy.clock import Clock
from rclpy.qos import qos_profile_sensor_data
import time

class BmiNode(Node):
    def __init__(self):
        super().__init__('bmi_node')
        self.imu = BMI270(1,0x68)
        self.imu.load_config_file()
        self.imu.set_mode("performance")
        self.imu.set_acc_range()
        self.imu.set_gyr_range()
        
        
        self.publisher_ = self.create_publisher(Imu, '/imu0', qos_profile_sensor_data)
        self.timer = self.create_timer(0.005, self.publish_imu_data)
        self.time_offset = 0.187486

    def publish_imu_data(self):        
        t1 = time.time()
        acc, gyro = self.imu.get_acc_gyro_data()
        t2 = time.time()
        t_sample = (t1 + t2)/2 + self.time_offset
        
        msg = Imu()
        secs = int(t_sample)
        nsecs = int((t_sample - secs) * 1e9)
        msg.header.stamp.sec = secs
        msg.header.stamp.nanosec = nsecs
        
        msg.header.frame_id = 'imu'
        
        #G = 9.80665
        #DEG2RAD = 3.14159/180.0
        msg.linear_acceleration.x = acc[0]
        msg.linear_acceleration.y = acc[1]
        msg.linear_acceleration.z = acc[2]
        msg.angular_velocity.x = gyro[0]
        msg.angular_velocity.y = gyro[1]
        msg.angular_velocity.z = gyro[2]
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = BmiNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
