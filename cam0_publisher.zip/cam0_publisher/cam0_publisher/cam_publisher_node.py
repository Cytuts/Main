import cv2
import time
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from rclpy.qos import QoSPresetProfiles

class CamPublisher(Node):
    def __init__(self):
        super().__init__('cam0_node')
        qos = QoSPresetProfiles.SENSOR_DATA.value
        self.publisher_ = self.create_publisher(Image, '/cam0/image_raw', qos)

        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz
        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.bridge = CvBridge()
        if not self.cap.isOpened():
            self.get_logger().error("Failed to open camera")

    def timer_callback(self):
        t1 = time.time()
        ret, frame = self.cap.read()
        t2 = time.time()
        if not ret:
            self.get_logger().warning("Failed to capture")
            return

        t_sample = (t1 + t2) / 2.0
        secs = int(t_sample)
        nsecs = int((t_sample - secs) * 1e9)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        msg = self.bridge.cv2_to_imgmsg(gray, encoding='mono8')
        msg.header.stamp.sec = secs
        msg.header.stamp.nanosec = nsecs
        msg.header.frame_id = "cam0"
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = CamPublisher()
    rclpy.spin(node)
    node.cap.release()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
